[General]
IsInChuckSpace=0
